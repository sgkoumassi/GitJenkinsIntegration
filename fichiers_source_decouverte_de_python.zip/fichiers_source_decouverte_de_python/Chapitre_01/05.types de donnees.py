# les types sont des objets
"abcdef".capitalize()
"abcdef".split("d")
# retourne une liste
"abcdef".partition("d")
# retourne un tuple

# listes
l = [1, "coucou", [2,3]]
type(l)
l
l[2]

l.index("coucou")
l.index([2, 3])
dir(l)

l.append("dalek2")
l.insert(0, "dalek1")
l.pop()

