class EpisodeDrWho:
    """
    Un épisode du Docteur Who
    """

ep = EpisodeDrWho()

ep.saison = 7
ep.episode = 5

print(ep.saison) 
