from Television.SerieTele import EpisodeDrWho 

ep = EpisodeDrWho(7, 5)

ep.attaque_dalek()
ep.diffuser()


__init__.py
